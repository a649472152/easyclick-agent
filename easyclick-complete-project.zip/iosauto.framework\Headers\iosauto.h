//
//  iosauto.h
//  iosauto
//
//  Created by wangbx on 2022/11/28.
//

#import <Foundation/Foundation.h>

//! Project version number for iosauto.
FOUNDATION_EXPORT double iosautoVersionNumber;

//! Project version string for iosauto.
FOUNDATION_EXPORT const unsigned char iosautoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iosauto/PublicHeader.h>
#import <iosauto/FindColorMatObjc.h>
//#import <iosauto/MatchTmplObjc.h>
//#import <iosauto/OcrLiteObjc.h>
//#import <iosauto/PaddleLiteObjc.h>
//#import <iosauto/yolo.h>
